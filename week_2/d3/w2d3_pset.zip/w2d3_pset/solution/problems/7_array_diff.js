/***********************************************************************
Write a function arrayDiff(arr1, arr2) that takes in 2 arrays. Return a
new array where all arr1 elements are removed if they are the same element
as arr2.
***********************************************************************/

//Example:
// array1 = [1,23,2,43,3,4]
// array2 = [3, 23]
// arrayDiff(array1, array2) // => [1, 2, 43 ,4]

// array3 = ['a', 'ab', 'c', 'd', 'c']
// array4 = ['d']
// arrayDiff(array3, array4) // => ['a', 'ab', 'c', 'c']

function arrayDiff(arr1, arr2){
  var arr = [];

  for(var i = 0; i < arr1.length; i++){
    var ele = arr1[i];

    if(arr2.indexOf(ele) < 0) {
      arr.push(ele);
    }
  }

  return arr;
}

/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
module.exports = arrayDiff;